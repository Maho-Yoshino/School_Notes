﻿using System;
using System.Linq;

namespace dolgozat_2024_12_03
{
	class Program
	{
		/// <summary>
		/// egy héten keresztül Rudi minden nap elment autózni, minden nap rögzítette, hogy hány km-t tett meg. átlagosan hány km-t tett meg a héten, hányszor ment 30km-nél többet, hány km volt a leghosszabb, legrövidebb útja?
		/// </summary>
		static void Main(string[] args)
		{
			Console.Write("Adja meg, hány napos volt a mérés: ");
			int N = int.Parse(Console.ReadLine());
			int[] nap_km = new int[N];
			for (int i = 0; i < N; i++)
			{
				Console.Write($"{i + 1}. mérés: ");
				nap_km[i] = int.Parse(Console.ReadLine());
			}
			int atlag_felso = 0;
			int tobb_30km = 0;
			foreach (int nap in nap_km)
			{
				if (nap > 30)
				{
					tobb_30km += 1;
				}
				atlag_felso += nap;
			}
			Console.WriteLine($"\nA mérések alapján\n\t{nap_km.Max()}km volt a leghosszabb út\n\t{nap_km.Min()}km volt a legrövidebb út\n\tÁtlagosan {Math.Round(Convert.ToDouble(atlag_felso) / N, 2)}km-t ment\n\t{tobb_30km}x ment több, mint 30 km-t");
			Console.ReadKey();
		}
	}
}
