'''Írj eljárást, amely egy tetszőleges szöveget, ill. alakzatot ír ki a képernyőre!'''
def szoveg():
	print("I got a feeling")
szoveg()